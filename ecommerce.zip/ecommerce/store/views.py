from django.shortcuts import render, redirect, get_object_or_404
from .models import Product, Order, OrderItem, Category
from django.contrib import messages
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from .forms import ProfileForm
from django.contrib.auth.forms import UserChangeForm
from .forms import CustomUserCreationForm
# store/views.py
from django.template.loader import render_to_string
from django.core.mail import EmailMessage
from django.contrib.auth.models import User
# store/views.py
from django.contrib.auth import login

# store/views.py

def category_list(request):
    categories = Category.objects.all()
    return render(request, "store/categories.html", {"categories": categories})

def category_detail(request, slug):
    category = Category.objects.get(slug=slug)
    products = category.products.all()
    return render(request, "store/category_detail.html", {"category": category, "products": products})

def custom_logout(request):
    logout(request)
    messages.info(request, "You have been logged out.")
    return redirect('home')

@login_required
def user_profile(request):
    user_orders = Order.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'profile.html', {
        'user': request.user,
        'orders': user_orders
    })

def admin_order_list(request):
    orders = Order.objects.all().order_by('-created_at')
    return render(request, 'admin_order_list.html', {'orders': orders})


@login_required
def order_history(request):
    orders = Order.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'order_history.html', {'orders': orders})

def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.is_active = False  # Deactivate until verified
            user.save()

            current_site = get_current_site(request)
            mail_subject = 'Activate your account'
            message = render_to_string('account_activation_email.html', {
                'user': user,
                'domain': current_site.domain,
                'uid': urlsafe_base64_encode(force_bytes(user.pk)),
                'token': account_activation_token.make_token(user),
            })
            email = EmailMessage(mail_subject, message, to=[user.email])
            email.send()
            messages.succcess(request, "Activation link sent to your mail please check your mail.")
            return redirect('home')
    else:
        form = CustomUserCreationForm()
    return render(request, 'register.html', {'form': form})



@login_required
def checkout(request):
    cart = request.session.get('cart', {})

    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        address = request.POST.get('address')

        order = Order.objects.create(
            user=request.user,
            name=name,
            email=email,
            address=address
        )

        for product_id, quantity in cart.items():
            product = Product.objects.get(id=product_id)
            OrderItem.objects.create(
                order=order,
                product=product,
                quantity=quantity,  # ✔️ directly use the int
                price=product.price
            )

        request.session['cart'] = {}  # clear cart
        messages.success(request, "Your order was placed successfully!")
        return redirect('home')

    # Pre-fill form with user data if available
    name = request.user.get_full_name()
    email = request.user.email

    return render(request, 'checkout.html', {
        'cart': cart,
        'name': name,
        'email': email,
    })


def add_to_cart(request, product_id):
    cart = request.session.get('cart', {})
    cart[str(product_id)] = cart.get(str(product_id), 0) + 1
    request.session['cart'] = cart
    return redirect('cart')

        
def cart(request):
    cart = request.session.get('cart', {})
    cart_items = []
    total = 0

    for product_id, quantity in cart.items():
        product = Product.objects.get(id=product_id)
        subtotal = product.price * quantity
        cart_items.append({
            'product': product,
            'quantity': quantity,
            'subtotal': subtotal
        })
        total += subtotal

    return render(request, 'cart.html', {
        'cart_items': cart_items,
        'total': total
    })

      

def home(request):
    products = Product.objects.all()
    return render(request, 'home.html', {'products': products})




def remove_from_cart(request, product_id):
    cart = request.session.get('cart', {})
    cart.pop(str(product_id), None)
    request.session['cart'] = cart
    return redirect('cart')

    
@login_required
def edit_profile(request):
    if request.method == 'POST':
        user_form = UserChangeForm(request.POST, instance=request.user)
        profile_form = ProfileForm(request.POST, instance=request.user.profile)

        if user_form.is_valid() and profile_form.is_valid():
            user_form.save()
            profile_form.save()
            messages.success(request, 'Your profile has been updated!')
            return redirect('user_profile')

    else:
        user_form = UserChangeForm(instance=request.user)
        profile_form = ProfileForm(instance=request.user.profile)

    return render(request, 'edit_profile.html', {
        'user_form': user_form,
        'profile_form': profile_form
    })



def profile_view(request):
    return render(request, 'profile.html')